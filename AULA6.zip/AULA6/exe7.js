let entrada = String(prompt("Insira qual tipo de entrada.\n 1. inteira\n 2. metade: "))
let preco = 0